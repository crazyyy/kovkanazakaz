<?xml version="1.0" encoding="ISO-8859-1"?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Object not found!</title>
<link rev="made" href="mailto:support@sweb.ru" />
<style type="text/css"><!--/*--><![CDATA[/*><!--*/ 
    body { color: #000000; background-color: #FFFFFF; }
    a:link { color: #0000CC; }
    p, address {margin-left: 3em;}
    span {font-size: smaller;}
/*]]>*/--></style>
</head>

<body>
<h1>Object not found!</h1>
<p>


    The requested URL was not found on this server.

  

    The link on the
    <a href="http://kovkanazakaz.com/">referring
    page</a> seems to be wrong or outdated. Please inform the author of
    <a href="http://kovkanazakaz.com/">that page</a>
    about the error.

  

</p>
<p>
If you think this is a server error, please contact
the <a href="mailto:support@sweb.ru">webmaster</a>.

</p>

<h2>Error 404</h2>
<address>
  <a href="/">kovkanazakaz.com</a><br />
  
  <span>Tue Mar 31 17:46:25 2015<br />
  Apache/2.2.29 (Gentoo) mod_dp/0.99.6 Phusion_Passenger/3.0.21 PHP/5.3.29-pl0-gentoo mod_wsgi/3.5 Python/2.7.5</span>
</address>
</body>
</html>

